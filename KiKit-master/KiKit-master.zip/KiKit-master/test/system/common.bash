#!/usr/bin/env bash

RES="$(dirname $(dirname $BATS_TEST_FILENAME))/resources"

