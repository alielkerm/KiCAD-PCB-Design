# Acknowledgements

The project is supported by:

- [My GitHub sponsors](https://github.com/sponsors/yaqwsx) and
- [<img src="https://nlnet.nl/logo/banner.svg" width="150"/>](https://nlnet.nl/project/KiKit/#ack)

Thank you all!
