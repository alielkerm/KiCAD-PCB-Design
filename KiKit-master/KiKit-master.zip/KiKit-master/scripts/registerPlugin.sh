#!/usr/bin/env sh

echo "import kikit.plugin" > ~/.kicad_plugins/kikit_plugin.py